import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Lightbulb, Zap, Target, CheckCircle, Clock, BookOpen, Users, Brain, Shield, Sparkles, GraduationCap, TrendingUp, Mail } from 'lucide-react'
import module1Visual from './assets/module1_visual.png'
import module2Visual from './assets/module2_visual.png'
import module3Visual from './assets/module3_visual.png'

// Glass morphism styles
const glassStyles = {
  glass: {
    background: 'rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(20px)',
    WebkitBackdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
    borderRadius: '30px',
    boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.37)',
  },
  glassCard: {
    background: 'rgba(255, 255, 255, 0.15)',
    backdropFilter: 'blur(15px)',
    WebkitBackdropFilter: 'blur(15px)',
    border: '1px solid rgba(255, 255, 255, 0.18)',
    borderRadius: '24px',
    boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
  },
  glassButton: {
    background: 'rgba(255, 255, 255, 0.2)',
    backdropFilter: 'blur(10px)',
    WebkitBackdropFilter: 'blur(10px)',
    border: '1px solid rgba(255, 255, 255, 0.3)',
    borderRadius: '20px',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  }
}

function CoursePage() {
  const navigate = useNavigate()
  const [activeModule, setActiveModule] = useState(1)

  const modules = [
    {
      id: 1,
      title: "AI Foundations & Ethical Practice",
      subtitle: "Understanding AI and its ethical implications",
      duration: "60 minutes",
      icon: <Lightbulb className="w-8 h-8" />,
      color: "from-[#e63946] to-[#f77f00]",
      visual: module1Visual,
      overview: "This foundational module introduces educators to the core concepts of artificial intelligence, demystifying the technology and establishing a framework for ethical, responsible implementation in educational settings.",
      learningOutcomes: [
        "Understand what AI is and how it works at a fundamental level",
        "Recognize different types of AI and their applications in education",
        "Identify ethical considerations and potential biases in AI systems",
        "Develop a framework for responsible AI use in teaching",
        "Explore the future trajectory of AI in education"
      ],
      keyTopics: [
        {
          title: "What is AI?",
          description: "Demystifying artificial intelligence, machine learning, and neural networks with practical, teacher-friendly explanations"
        },
        {
          title: "How AI Works",
          description: "Understanding the basics of AI training, data processing, and decision-making without requiring technical expertise"
        },
        {
          title: "AI Ethics & Bias",
          description: "Exploring ethical considerations, data privacy, algorithmic bias, and the importance of human oversight"
        },
        {
          title: "AI in Education Today",
          description: "Current applications of AI in classrooms, from adaptive learning platforms to automated grading systems"
        },
        {
          title: "The Future of AI",
          description: "Emerging trends, potential developments, and preparing for an AI-integrated educational landscape"
        }
      ],
      practicalActivities: [
        "Hands-on demonstration of AI tools to understand their capabilities and limitations",
        "Group discussion on ethical scenarios involving AI in education",
        "Case study analysis of successful and problematic AI implementations"
      ],
      takeaways: "Participants will leave with a solid understanding of AI fundamentals, the confidence to discuss AI with colleagues and students, and a critical lens for evaluating AI tools and applications."
    },
    {
      id: 2,
      title: "The AI-Powered Teacher",
      subtitle: "Leveraging AI to enhance teaching effectiveness",
      duration: "60 minutes",
      icon: <Zap className="w-8 h-8" />,
      color: "from-[#e63946] to-[#f77f00]",
      visual: module2Visual,
      overview: "This practical, hands-on module empowers teachers to leverage AI tools for lesson planning, resource creation, assessment design, and administrative efficiency—freeing up valuable time for meaningful student interaction.",
      learningOutcomes: [
        "Master prompt engineering techniques for effective AI interaction",
        "Use AI to create lesson plans, worksheets, and assessment materials",
        "Automate administrative tasks and streamline classroom management",
        "Develop custom AI assistants tailored to specific teaching needs",
        "Integrate AI tools into existing teaching workflows seamlessly"
      ],
      keyTopics: [
        {
          title: "Prompt Engineering Fundamentals",
          description: "Learn how to craft effective prompts that generate high-quality, relevant outputs from AI tools"
        },
        {
          title: "AI for Lesson Planning",
          description: "Using AI to design engaging lesson plans, create differentiated materials, and develop learning sequences"
        },
        {
          title: "Resource Creation",
          description: "Generating worksheets, quizzes, rubrics, and visual aids with AI assistance"
        },
        {
          title: "AI Tool Exploration",
          description: "Hands-on practice with ChatGPT, Google Gemini, Microsoft Copilot, and education-specific AI platforms"
        },
        {
          title: "Custom GPTs & AI Assistants",
          description: "Creating personalized AI assistants trained on your curriculum, teaching style, and student needs"
        },
        {
          title: "Time-Saving Workflows",
          description: "Automating feedback, grading support, parent communication, and administrative documentation"
        }
      ],
      practicalActivities: [
        "Live demonstration of prompt engineering with real teaching scenarios",
        "Guided practice creating lesson plans and resources using AI",
        "Workshop session: Build your own custom GPT for your classroom",
        "Peer sharing of AI-generated materials and best practices"
      ],
      takeaways: "Teachers will gain practical skills to immediately integrate AI into their daily workflow, saving hours per week while improving the quality and personalization of their teaching materials."
    },
    {
      id: 3,
      title: "The AI-Ready Classroom",
      subtitle: "Preparing students for an AI-integrated future",
      duration: "60 minutes",
      icon: <Target className="w-8 h-8" />,
      color: "from-[#e63946] to-[#f77f00]",
      visual: module3Visual,
      overview: "This forward-thinking module prepares educators to guide students in responsible AI use, adapt assessment strategies for an AI-enabled world, and foster critical thinking skills essential for the future workforce.",
      learningOutcomes: [
        "Understand how students are currently using AI (and why)",
        "Teach students to use AI responsibly and ethically",
        "Design AI-resistant and AI-integrated assessments",
        "Develop policies and guidelines for AI use in the classroom",
        "Foster critical thinking and AI literacy in students"
      ],
      keyTopics: [
        {
          title: "Student AI Use Patterns",
          description: "Understanding how and why students are using AI tools, from homework help to creative projects"
        },
        {
          title: "Teaching Responsible AI Use",
          description: "Strategies for guiding students to use AI as a learning tool rather than a shortcut"
        },
        {
          title: "AI Literacy for Students",
          description: "Developing critical thinking skills to evaluate AI outputs, recognize bias, and understand limitations"
        },
        {
          title: "Adapting Assessments",
          description: "Redesigning assignments and exams to be AI-resistant or to meaningfully incorporate AI"
        },
        {
          title: "Detection & Academic Integrity",
          description: "Understanding AI detection tools, their limitations, and building a culture of honest AI use"
        },
        {
          title: "Classroom Policies",
          description: "Creating clear, fair guidelines for when and how students can use AI in your classroom"
        }
      ],
      practicalActivities: [
        "Review and analyze student work created with AI assistance",
        "Workshop: Design an AI-integrated assessment for your subject area",
        "Collaborative development of classroom AI use policies",
        "Discussion of real-world scenarios and ethical dilemmas"
      ],
      takeaways: "Educators will be equipped to proactively address student AI use, create fair and effective assessment strategies, and prepare students to thrive in an AI-integrated future while maintaining academic integrity."
    }
  ]

  const currentModule = modules[activeModule - 1]

  return (
    <div className="min-h-screen pt-24 relative overflow-hidden" style={{
      background: 'linear-gradient(135deg, #1a365d 0%, #2a6496 50%, #457b9d 100%)'
    }}>
      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute w-96 h-96 bg-cyan-300 rounded-full blur-3xl animate-pulse" style={{top: '10%', left: '10%', animationDuration: '4s'}}></div>
        <div className="absolute w-96 h-96 bg-blue-400 rounded-full blur-3xl animate-pulse" style={{top: '50%', right: '10%', animationDuration: '6s', animationDelay: '1s'}}></div>
        <div className="absolute w-96 h-96 bg-purple-400 rounded-full blur-3xl animate-pulse" style={{bottom: '10%', left: '30%', animationDuration: '5s', animationDelay: '2s'}}></div>
      </div>
      {/* Moving Grid Pattern Overlay */}
      <div className="absolute inset-0 opacity-5" style={{
        backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
        backgroundSize: '50px 50px',
        animation: 'gridMove 20s linear infinite'
      }}></div>
      <style>{`
        @keyframes gridMove {
          0% { transform: translate(0, 0); }
          100% { transform: translate(50px, 50px); }
        }
      `}</style>
      {/* Hero Section */}
      <section className="py-20 relative z-10">
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="max-w-4xl mx-auto animate-fadeInUp">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white">
              Professional Development Course
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-white/90">
              A comprehensive three-module program designed to transform teachers into confident AI educators
            </p>
            <div className="flex items-center justify-center gap-4 text-white/80">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                <span>3 x 60-minute modules</span>
              </div>
              <span>•</span>
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                <span>In-person delivery</span>
              </div>
              <span>•</span>
              <div className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5" />
                <span>AITSL aligned</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Module Navigation */}
      <section className="py-8 relative">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
            {modules.map((module) => (
              <button
                key={module.id}
                onClick={() => setActiveModule(module.id)}
                className={`px-6 py-3 text-lg rounded-3xl font-semibold transition-all duration-300 glass-button-hover ${
                  activeModule === module.id
                    ? "text-white shadow-lg"
                    : "text-white/80 hover:text-white"
                }`}
                style={{
                  ...glassStyles.glassButton,
                  background: activeModule === module.id 
                    ? 'rgba(230, 57, 70, 0.8)' 
                    : glassStyles.glassButton.background
                }}
              >
                {module.icon}
                <span className="ml-2">Module {module.id}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Module Details */}
      <section className="py-12 relative">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            {/* Module Header */}
            <div 
              className="overflow-hidden rounded-[32px] mb-8 animate-scaleIn"
              style={glassStyles.glassCard}
            >
              <div className={`bg-gradient-to-r ${currentModule.color} p-8`}>
                <div className="flex flex-col md:flex-row items-center gap-6">
                  <div className="flex-1 text-white">
                    <div className="flex items-center gap-3 mb-2">
                      {currentModule.icon}
                      <h2 className="text-3xl md:text-4xl font-bold">
                        Module {currentModule.id}: {currentModule.title}
                      </h2>
                    </div>
                    <p className="text-xl opacity-90 mb-3">
                      {currentModule.subtitle}
                    </p>
                    <div className="flex items-center gap-2 text-sm opacity-80">
                      <Clock className="w-4 h-4" />
                      {currentModule.duration}
                    </div>
                  </div>
                  <div className="w-48 h-48 md:w-64 md:h-64 flex-shrink-0">
                    <img 
                      src={currentModule.visual} 
                      alt={currentModule.title}
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Overview */}
            <div 
              className="p-8 rounded-[32px] mb-8 animate-fadeInUp transition-all duration-300 hover:scale-105 hover:shadow-2xl"
              style={{...glassStyles.glass, animationDelay: '0.1s'}}
            >
              <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                <BookOpen className="w-6 h-6 text-cyan-300" />
                Module Overview
              </h3>
              <p className="text-white/90 text-lg leading-relaxed">
                {currentModule.overview}
              </p>
            </div>

            {/* Learning Outcomes */}
            <div 
              className="p-8 rounded-[32px] mb-8 animate-fadeInUp transition-all duration-300 hover:scale-105 hover:shadow-2xl"
              style={{...glassStyles.glass, animationDelay: '0.2s'}}
            >
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-cyan-300" />
                Learning Outcomes
              </h3>
              <div className="space-y-3">
                {currentModule.learningOutcomes.map((outcome, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-[#e63946] flex-shrink-0 mt-1" />
                    <span className="text-white/90 text-lg">{outcome}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Key Topics */}
            <div 
              className="p-8 rounded-[32px] mb-8 animate-fadeInUp transition-all duration-300 hover:scale-105 hover:shadow-2xl"
              style={{...glassStyles.glass, animationDelay: '0.3s'}}
            >
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                <Brain className="w-6 h-6 text-cyan-300" />
                Key Topics Covered
              </h3>
              <div className="grid md:grid-cols-2 gap-6">
                {currentModule.keyTopics.map((topic, index) => (
                  <div 
                    key={index}
                    className="p-6 rounded-[24px] animate-fadeInUp"
                    style={{
                      background: 'rgba(255, 255, 255, 0.1)',
                      border: '1px solid rgba(255, 255, 255, 0.2)',
                      animationDelay: `${0.4 + index * 0.1}s`
                    }}
                  >
                    <h4 className="text-xl font-semibold text-white mb-2">
                      {topic.title}
                    </h4>
                    <p className="text-white/80 leading-relaxed">
                      {topic.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Practical Activities */}
            <div 
              className="p-8 rounded-[32px] mb-8 animate-fadeInUp transition-all duration-300 hover:scale-105 hover:shadow-2xl"
              style={{...glassStyles.glass, animationDelay: '0.4s'}}
            >
              <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-cyan-300" />
                Practical Activities
              </h3>
              <div className="space-y-3">
                {currentModule.practicalActivities.map((activity, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-cyan-300/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-cyan-300 font-bold">{index + 1}</span>
                    </div>
                    <span className="text-white/90 text-lg">{activity}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Key Takeaways */}
            <div 
              className="p-8 rounded-[32px] mb-8 animate-fadeInUp transition-all duration-300 hover:scale-105 hover:shadow-2xl"
              style={{...glassStyles.glass, animationDelay: '0.5s'}}
            >
              <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                <Shield className="w-6 h-6 text-cyan-300" />
                Key Takeaways
              </h3>
              <p className="text-white/90 text-lg leading-relaxed">
                {currentModule.takeaways}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 relative">
        <div className="container mx-auto px-4">
          <div 
            className="max-w-4xl mx-auto p-8 rounded-[32px] text-center"
            style={glassStyles.glassCard}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white">
              Ready to Bring This Course to Your School?
            </h2>
            <p className="text-xl mb-8 text-white/90 max-w-3xl mx-auto">
              Our comprehensive three-module program can be delivered at your school, tailored to your staff's needs and schedule.
            </p>
            <button 
              onClick={() => navigate('/contact')}
              className="px-8 py-4 text-lg font-semibold text-white rounded-3xl glass-button-hover cursor-pointer"
              style={{
                ...glassStyles.glassButton,
                background: 'rgba(230, 57, 70, 0.8)'
              }}
            >
              <Mail className="w-5 h-5 mr-2 inline" />
              Get in Touch Today
            </button>
          </div>
        </div>
      </section>
    </div>
  )
}

export default CoursePage

