import React, { useState, useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom'
import { Button } from './components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card'
import { Badge } from './components/ui/badge'
import { Lightbulb, Award, Target, Star, MapPin, BookOpen, Zap, CheckCircle, Clock, Mail, Shield, Users, Building2, Heart, Briefcase, Send, User, GraduationCap, Phone } from 'lucide-react'
import cogniaLogo from './assets/cognia_logo_horizontal.png'
import CoursePage from './CoursePage'
import teamHeadshot from './assets/team_headshot.jpg'
import heroBackground from './assets/hero_background.png'
import module1Visual from './assets/module1_visual.png'
import module2Visual from './assets/module2_visual.png'
import module3Visual from './assets/module3_visual.png'
import benefitsGraphic from './assets/benefits_graphic.png'
import './App.css'

// Glass morphism styles
const glassStyles = {
  glass: {
    background: 'rgba(255, 255, 255, 0.1)',
    backdropFilter: 'blur(20px)',
    WebkitBackdropFilter: 'blur(20px)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
    borderRadius: '30px',
    boxShadow: '0 8px 32px 0 rgba(31, 38, 135, 0.37)',
  },
  glassCard: {
    background: 'rgba(255, 255, 255, 0.15)',
    backdropFilter: 'blur(15px)',
    WebkitBackdropFilter: 'blur(15px)',
    border: '1px solid rgba(255, 255, 255, 0.18)',
    borderRadius: '24px',
    boxShadow: '0 4px 30px rgba(0, 0, 0, 0.1)',
  },
  glassButton: {
    background: 'rgba(255, 255, 255, 0.2)',
    backdropFilter: 'blur(10px)',
    WebkitBackdropFilter: 'blur(10px)',
    border: '1px solid rgba(255, 255, 255, 0.3)',
    borderRadius: '20px',
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  }
}

// Animation keyframes
const animationStyles = `
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(30px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes slideInLeft {
    from {
      opacity: 0;
      transform: translateX(-50px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes slideInRight {
    from {
      opacity: 0;
      transform: translateX(50px);
    }
    to {
      opacity: 1;
      transform: translateX(0);
    }
  }

  @keyframes scaleIn {
    from {
      opacity: 0;
      transform: scale(0.9);
    }
    to {
      opacity: 1;
      transform: scale(1);
    }
  }

  @keyframes float {
    0%, 100% {
      transform: translateY(0px);
    }
    50% {
      transform: translateY(-10px);
    }
  }

  @keyframes pulse {
    0%, 100% {
      transform: scale(1);
    }
    50% {
      transform: scale(1.05);
    }
  }

  .animate-fadeInUp {
    animation: fadeInUp 0.8s ease-out forwards;
  }

  .animate-slideInLeft {
    animation: slideInLeft 0.8s ease-out forwards;
  }

  .animate-slideInRight {
    animation: slideInRight 0.8s ease-out forwards;
  }

  .animate-scaleIn {
    animation: scaleIn 0.6s ease-out forwards;
  }

  .animate-float {
    animation: float 3s ease-in-out infinite;
  }

  .animate-pulse-slow {
    animation: pulse 2s ease-in-out infinite;
  }

  .glass-hover {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .glass-hover:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
    background: rgba(255, 255, 255, 0.25);
  }

  .glass-button-hover {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .glass-button-hover:hover {
    transform: translateY(-2px);
    background: rgba(255, 255, 255, 0.3);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  }

  .stagger-animation > * {
    opacity: 0;
    animation: fadeInUp 0.8s ease-out forwards;
  }

  .stagger-animation > *:nth-child(1) { animation-delay: 0.1s; }
  .stagger-animation > *:nth-child(2) { animation-delay: 0.2s; }
  .stagger-animation > *:nth-child(3) { animation-delay: 0.3s; }
  .stagger-animation > *:nth-child(4) { animation-delay: 0.4s; }
  .stagger-animation > *:nth-child(5) { animation-delay: 0.5s; }
  .stagger-animation > *:nth-child(6) { animation-delay: 0.6s; }
`

// Add styles to document head
if (typeof document !== 'undefined') {
  const styleSheet = document.createElement('style')
  styleSheet.textContent = animationStyles
  document.head.appendChild(styleSheet)
}

// Header Component
function Header() {
  const location = useLocation()
  
  return (
    <header className="fixed top-0 left-0 right-0 z-50 animate-slideInLeft backdrop-blur-md shadow-lg" style={glassStyles.glass}>
      <div className="w-full px-6 py-4">
        <div className="flex items-center relative">
          {/* Logo - Far Left */}
          <div className="flex-shrink-0">
            <Link to="/" className="hover:opacity-90 transition-opacity inline-block">
              <img 
                src={cogniaLogo} 
                alt="Cognia Education" 
                className="h-20 w-auto rounded-3xl transition-transform duration-300 hover:scale-105"
              />
            </Link>
          </div>
          
          {/* Title - Absolute Center */}
          <div className="absolute left-1/2 transform -translate-x-1/2 hidden md:block pointer-events-none">
            <Link to="/" className="pointer-events-auto">
              <span className="text-4xl font-bold text-white hover:text-cyan-300 transition-colors duration-300 whitespace-nowrap">Cognia Education</span>
            </Link>
          </div>
          
          {/* Navigation - Far Right */}
          <div className="flex-shrink-0 ml-auto">
            <nav className="flex space-x-1 items-center">
            {[
              { label: 'Home', path: '/' },
              { label: 'Course', path: '/course' },
              { label: 'About Us', path: '/about' },
              { label: 'Contact Us', path: '/contact' }
            ].map((item, index) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-3 py-2 md:px-6 md:py-3 rounded-3xl text-sm md:text-lg font-medium transition-all duration-300 glass-button-hover whitespace-nowrap ${
                  location.pathname === item.path
                    ? 'text-[#e63946] shadow-lg'
                    : 'text-white hover:text-[#e63946]'
                }`}
                style={{
                  ...glassStyles.glassButton,
                  animationDelay: `${index * 0.1}s`,
                  background: location.pathname === item.path 
                    ? 'rgba(230, 57, 70, 0.2)' 
                    : glassStyles.glassButton.background
                }}
              >
                {item.label}
              </Link>
            ))}
            </nav>
          </div>
        </div>
      </div>
    </header>
  )
}

// Statistics Carousel Component
function StatisticsCarousel() {
  const [currentStat, setCurrentStat] = React.useState(0)
  
  const statistics = [
    {
      fact: "87% of students are already using AI tools",
      description: "A majority of students have experimented with AI for homework, research, and creative projects—often without teacher guidance.",
      percentage: 87,
      source: "Australian EdTech Survey 2024"
    },
    {
      fact: "Only 23% of teachers feel confident using AI",
      description: "Despite widespread student adoption, less than a quarter of educators report feeling adequately prepared to integrate AI into their teaching.",
      percentage: 23,
      source: "AITSL Professional Learning Report 2024"
    },
    {
      fact: "AI can save teachers 13+ hours per week",
      description: "When used effectively, AI tools can automate administrative tasks, generate resources, and personalize learning—freeing up valuable time for teaching.",
      percentage: 65,
      source: "McKinsey Education Analysis 2024"
    },
    {
      fact: "92% of schools plan to adopt AI by 2025",
      description: "The vast majority of Australian schools are planning or already implementing AI technologies in their curriculum and operations.",
      percentage: 92,
      source: "Australian Schools Technology Report 2024"
    }
  ]
  
  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStat((prev) => (prev + 1) % statistics.length)
    }, 6000) // Change every 6 seconds
    return () => clearInterval(interval)
  }, [])
  
  const currentData = statistics[currentStat]
  
  return (
    <div className="relative">
      <div 
        className="p-8 md:p-12 rounded-[48px] bg-white/90 min-h-[400px] flex flex-col md:flex-row items-center gap-8"
      >
        {/* Left side - Statistic visualization */}
        <div className="w-full md:w-1/2 flex items-center justify-center">
          <div className="relative w-64 h-64">
            {/* Circular progress bar */}
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="128"
                cy="128"
                r="100"
                stroke="#e0e0e0"
                strokeWidth="20"
                fill="none"
              />
              <circle
                cx="128"
                cy="128"
                r="100"
                stroke="#e63946"
                strokeWidth="20"
                fill="none"
                strokeDasharray={`${2 * Math.PI * 100}`}
                strokeDashoffset={`${2 * Math.PI * 100 * (1 - currentData.percentage / 100)}`}
                className="transition-all duration-1000 ease-in-out"
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-6xl font-bold text-[#1a365d]">{currentData.percentage}%</span>
            </div>
          </div>
        </div>
        
        {/* Right side - Text content */}
        <div className="w-full md:w-1/2 text-left">
          <h3 className="text-2xl md:text-3xl font-bold text-[#1a365d] mb-4 transition-all duration-500">
            {currentData.fact}
          </h3>
          <p className="text-lg text-gray-700 mb-4 leading-relaxed">
            {currentData.description}
          </p>
          <p className="text-sm text-gray-500 italic">
            Source: {currentData.source}
          </p>
        </div>
      </div>
      
      {/* Indicator dots */}
      <div className="flex justify-center gap-3 mt-6">
        {statistics.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentStat(index)}
            className={`transition-all duration-300 rounded-full ${
              currentStat === index 
                ? 'w-12 h-3 bg-[#e63946]' 
                : 'w-3 h-3 bg-white/50 hover:bg-white/80'
            }`}
            aria-label={`Go to statistic ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}

// Home Page Component
function HomePage() {
  const [activeModule, setActiveModule] = useState(1)
  const [isVisible, setIsVisible] = useState(false)
  const [currentQuote, setCurrentQuote] = React.useState(0)
  const navigate = useNavigate()

  useEffect(() => {
    setIsVisible(true)
  }, [])
  
  const inspiringQuotes = [
    {
      text: "AI will not replace teachers, but teachers who use AI will replace those who don't.",
      author: "Education Technology Insight"
    },
    {
      text: "The future of education is not about competing with AI, but collaborating with it.",
      author: "UNESCO Report on AI in Education"
    },
    {
      text: "Empowering teachers with AI literacy is empowering students with future-ready skills.",
      author: "OECD Education Framework"
    },
    {
      text: "AI in education is not a threat—it's an opportunity to enhance teaching and learning.",
      author: "World Economic Forum"
    },
    {
      text: "The best time to learn about AI was yesterday. The second best time is now.",
      author: "Cognia Education"
    }
  ]
  
  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % inspiringQuotes.length)
    }, 5000)
    
    return () => clearInterval(interval)
  }, [])

  const modules = [
    {
      id: 1,
      title: "AI Foundations & Ethical Practice",
      subtitle: "Understanding AI and building ethical frameworks",
      duration: "60 minutes",
      color: "from-[#1a365d] to-[#2a6496]",
      icon: <Lightbulb className="w-8 h-8" />,
      visual: module1Visual,
      description: "Build a strong foundation in AI understanding and establish ethical guidelines for responsible use in educational settings.",
      topics: [
        "What is Generative AI and how does it work?",
        "Ethical considerations and responsible use",
        "Identifying AI hallucinations and misinformation",
        "Privacy and data protection in AI tools"
      ]
    },
    {
      id: 2,
      title: "The AI-Powered Teacher",
      subtitle: "Practical AI applications for educators",
      duration: "60 minutes",
      color: "from-[#2a6496] to-[#457b9d]",
      icon: <Target className="w-8 h-8" />,
      visual: module2Visual,
      description: "Discover hands-on AI applications that can transform your teaching workflow and enhance your professional practice.",
      topics: [
        "Prompt engineering for educational tasks",
        "AI-assisted lesson planning and curriculum design",
        "Creating custom GPTs for specific subjects",
        "Time-saving administrative applications"
      ]
    },
    {
      id: 3,
      title: "The AI-Ready Classroom",
      subtitle: "Preparing students for an AI-enabled future",
      duration: "60 minutes",
      color: "from-[#457b9d] to-[#e63946]",
      icon: <Users className="w-8 h-8" />,
      visual: module3Visual,
      description: "Learn how to guide students in responsible AI use while adapting your classroom practices for the AI era.",
      topics: [
        "How students are currently using AI",
        "Teaching AI literacy and digital citizenship",
        "Designing AI-resistant and AI-enhanced assessments",
        "Classroom policies for responsible AI use"
      ]
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a365d] via-[#2a6496] to-[#457b9d]">
      {/* Hero Section */}
      <section 
        className="relative text-white pt-32 pb-20 overflow-hidden"
        style={{
          backgroundImage: `url(${heroBackground})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundBlendMode: 'overlay'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a365d]/50 to-[#2a6496]/50"></div>
        

        
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className={`max-w-4xl mx-auto ${isVisible ? 'animate-fadeInUp' : 'opacity-0'}`}>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 hover:animate-pulse-slow">
              AI Proficiency for Educators
            </h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90 animate-slideInLeft" style={{animationDelay: '0.3s'}}>
              Empower your teachers with the skills and confidence to effectively integrate AI into their teaching practice
            </p>
            
            <div className="flex flex-wrap justify-center items-center gap-4 mb-8 stagger-animation">

              <button 
                onClick={() => navigate('/contact')}
                className="px-8 py-4 text-lg font-semibold text-white rounded-3xl glass-button-hover cursor-pointer"
                style={{
                  ...glassStyles.glassButton,
                  background: 'rgba(230, 57, 70, 0.8)'
                }}
              >
                <MapPin className="w-5 h-5 mr-2 inline" />
                Book Your Session Today
              </button>
            </div>
            
            {/* Rotating Quotes */}
            <div className="mt-12 max-w-4xl mx-auto">
              <div 
                className="p-8 rounded-[32px] min-h-[180px] flex flex-col justify-center items-center transition-all duration-1000"
                style={{
                  ...glassStyles.glass,
                  opacity: 1
                }}
              >
                <div className="transition-opacity duration-500" key={currentQuote}>
                  <p className="text-xl md:text-2xl text-white/95 italic mb-4 leading-relaxed">
                    "{inspiringQuotes[currentQuote].text}"
                  </p>
                  <p className="text-cyan-300 font-semibold">
                    — {inspiringQuotes[currentQuote].author}
                  </p>
                </div>
                
                {/* Quote indicators */}
                <div className="flex gap-2 mt-6">
                  {inspiringQuotes.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentQuote(index)}
                      className={`w-2 h-2 rounded-full transition-all duration-300 ${
                        index === currentQuote ? 'bg-cyan-300 w-8' : 'bg-white/30 hover:bg-white/50'
                      }`}
                      aria-label={`Go to quote ${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted Tools & Standards Section */}
      <section className="py-16 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 animate-fadeInUp">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Our Specialties
            </h2>
            <p className="text-lg text-white/80 max-w-3xl mx-auto">
              Our team is trained on industry-leading AI platforms and tools
            </p>
          </div>

          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
              {[
                { name: 'OpenAI', logo: '/logos/openai_logo.png', alt: 'OpenAI ChatGPT', url: 'https://openai.com', size: 'max-h-12' },
                { name: 'Google', logo: '/logos/google_logo.png', alt: 'Google Gemini', url: 'https://gemini.google.com', size: 'max-h-12' },
                { name: 'Microsoft', logo: '/logos/microsoft_logo.jpg', alt: 'Microsoft', url: 'https://www.microsoft.com/ai', size: 'max-h-12' },
                { name: 'Copilot', logo: '/logos/copilot_logo_new.png', alt: 'Microsoft Copilot', url: 'https://copilot.microsoft.com', size: 'max-h-12' }
              ].map((tool, index) => (
                <a 
                  key={tool.name}
                  href={tool.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center p-6 rounded-3xl glass-hover animate-scaleIn bg-white/90 cursor-pointer"
                  style={{
                    animationDelay: `${index * 0.1}s`
                  }}
                >
                  <img 
                    src={tool.logo} 
                    alt={tool.alt}
                    className={`w-full h-auto ${tool.size} object-contain transition-transform duration-300 hover:scale-110`}
                    title={tool.alt}
                  />
                </a>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 animate-fadeInUp">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              AI in Education: The Facts
            </h2>
            <p className="text-lg text-white/80 max-w-3xl mx-auto">
              Understanding the impact and adoption of AI in Australian classrooms
            </p>
          </div>

          <div className="max-w-6xl mx-auto grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                stat: "87%",
                title: "Students Using AI",
                description: "Students have experimented with AI for homework and projects"
              },
              {
                stat: "23%",
                title: "Teachers Feel Confident",
                description: "Educators report feeling prepared to integrate AI"
              },
              {
                stat: "13+",
                title: "Hours Saved Per Week",
                description: "AI can automate tasks and free up teaching time"
              },
              {
                stat: "92%",
                title: "Schools Adopting AI",
                description: "Australian schools planning AI implementation by 2025"
              }
            ].map((item, index) => (
              <div 
                key={index}
                className="p-6 rounded-[32px] text-center animate-fadeInUp transition-transform duration-300 hover:scale-105 cursor-pointer"
                style={{
                  ...glassStyles.glassCard,
                  animationDelay: `${index * 0.1}s`
                }}
              >
                <div className="text-5xl font-bold text-white mb-3">
                  {item.stat}
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">
                  {item.title}
                </h3>
                <p className="text-white/80 text-sm">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Course Overview Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div 
              className="p-12 rounded-[32px] animate-fadeInUp transition-transform duration-300 hover:scale-105"
              style={glassStyles.glassCard}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                Three-Module Professional Development Program
              </h2>
              <p className="text-xl text-white/90 leading-relaxed mb-8">
                This comprehensive professional development program provides educators with a structured pathway from foundational AI knowledge to practical classroom implementation, preparing them to lead in AI-enabled educational environments. With widespread student adoption of AI technologies occurring in the absence of formal guidance, there exists an urgent need for educators to develop the competencies required to guide responsible AI engagement. This program delivers evidence-based training aligned with AITSL standards, equipping participants with the theoretical understanding and practical skills necessary for effective AI integration in contemporary teaching practice.
              </p>
              <button 
                onClick={() => navigate('/course')}
                className="px-8 py-4 text-lg font-semibold text-white rounded-3xl glass-button-hover cursor-pointer inline-flex items-center gap-2"
                style={{
                  ...glassStyles.glassButton,
                  background: 'rgba(230, 57, 70, 0.8)'
                }}
              >
                <BookOpen className="w-5 h-5" />
                Explore Our Course
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 relative">
        <div className="container mx-auto px-4 text-center">
          <div 
            className="max-w-4xl mx-auto p-8 rounded-[32px] glass-hover transition-transform duration-300 hover:scale-105"
            style={glassStyles.glassCard}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-white animate-fadeInUp">
              Ready to Transform Your School ?
            </h2>
            <p className="text-xl mb-8 text-white/90 max-w-3xl mx-auto animate-slideInLeft" style={{animationDelay: '0.2s'}}>
              Join the growing community of Australian schools that are leading the way in AI education.
            </p>
            <div className="flex flex-col md:flex-row justify-center items-center gap-6 stagger-animation">
              <button 
                onClick={() => navigate('/contact')}
                className="px-8 py-4 text-lg font-semibold text-white rounded-3xl glass-button-hover cursor-pointer"
                style={{
                  ...glassStyles.glassButton,
                  background: 'rgba(230, 57, 70, 0.8)'
                }}
              >
                <Mail className="w-5 h-5 mr-2 inline" />
                Get in Touch Today
              </button>
              <div className="text-center">
                <p className="text-lg font-semibold text-white">admin@cogniaedu.com.au</p>
                <p className="text-white/80">Serving schools across Australia</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

// About Page Component
function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a365d] via-[#2a6496] to-[#457b9d]">
      {/* Hero Section with Curved Bottom */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a365d]/50 to-[#2a6496]/50"></div>
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-br from-[#1a365d] via-[#2a6496] to-[#457b9d]" 
             style={{borderRadius: '50% 50% 0 0 / 100% 100% 0 0'}}>
        </div>
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 animate-fadeInUp">
            About Cognia Education
          </h1>
          <p className="text-2xl text-white/90 max-w-3xl mx-auto animate-slideInLeft" style={{animationDelay: '0.2s'}}>
            Pioneering AI education for Australian teachers and schools
          </p>
        </div>
      </section>

      {/* Mission Section - Organic Blob Shape */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div 
              className="p-12 md:p-16 animate-fadeInUp transition-transform duration-300 hover:scale-105"
              style={{
                ...glassStyles.glass,
                borderRadius: '48px',
                animationDelay: '0.3s'
              }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 text-center">
                Our Mission
              </h2>
              <p className="text-xl text-white/90 leading-relaxed text-center">
                At Cognia Education, we believe that every teacher deserves to feel confident and empowered in the age of artificial intelligence. Our mission is to bridge the gap between cutting-edge AI technology and practical classroom application, ensuring that Australian educators are not just prepared for the future—they're leading it.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Story Section - Another Organic Shape */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div 
              className="p-12 md:p-16 animate-fadeInUp transition-transform duration-300 hover:scale-105"
              style={{
                ...glassStyles.glass,
                borderRadius: '48px',
                animationDelay: '0.3s'
              }}
            >
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 text-center">
                Our Story
              </h2>
              <p className="text-lg text-white/90 leading-relaxed mb-6">
                Artificial intelligence is reshaping education at an unprecedented pace. Yet most educators face this transformation without adequate preparation or support. This gap between technological advancement and professional readiness has left many teachers feeling behind.
              </p>
              <p className="text-lg text-white/90 leading-relaxed mb-6">
                Cognia Education bridges this divide. We deliver AITSL-aligned professional development that transforms educators from AI observers into confident practitioners. Our training combines theoretical foundations with hands-on application, ensuring teachers can immediately implement what they learn.
              </p>
              <p className="text-lg text-white/90 leading-relaxed">
                Operating across Australia, our class leading tri-module program equips educators with practical AI integration strategies while addressing ethical considerations and maintaining alignment with Australian teaching standards. We don't just teach about AI, we prepare teachers to lead their classrooms into the future.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-fadeInUp">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Meet Our Management Team
            </h2>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              The passionate educators and AI specialists behind Cognia Education's innovative professional development programs
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-7xl mx-auto">
            {[
              {
                name: "Alif Rahman",
                role: "Co-Founder & Lead Educator",
                qualifications: "B.Eng Mechatronic Engineering, Graduate Diploma in Teaching",
                experience: "Extensive experience in primary and secondary education",
                expertise: ["AI in Education", "STEM Education", "Primary & Secondary Teaching", "Educational Technology", "AI Integration"],
                bio: "Alif Rahman co-founded Cognia Education with a passion for bridging technology and education. With a unique background in Mechatronic Engineering and teaching across primary and high school levels, Alif brings both technical expertise and practical classroom experience. As an AI enthusiast, he is dedicated to empowering teachers with the skills and confidence to integrate artificial intelligence into their teaching practice effectively."
              },
              {
                name: "Mahi Taher",
                role: "Co-Founder & IT Specialist",
                qualifications: "B.Sc Physics, IT Specialist Certification",
                experience: "Extensive experience in IT systems and educational technology",
                expertise: ["Information Technology", "Educational Systems", "Technical Infrastructure", "AI Tools Implementation", "Digital Solutions"],
                bio: "Mahi Taher co-founded Cognia Education with a vision to leverage technology for educational transformation. With a strong foundation in Physics and specialized expertise in IT, Mahi ensures that all technical aspects of our AI education programs are robust, accessible, and aligned with the needs of modern schools. His technical leadership enables seamless integration of AI tools into educational environments across Australia."
              },
              {
                name: "Khalid Sheikh",
                role: "Content Development Adviser",
                qualifications: "B.Ed Secondary Education, Content Development Certification",
                experience: "Experienced high school teacher and curriculum developer",
                expertise: ["Curriculum Design", "Content Development", "Secondary Education", "Pedagogical Strategy", "Educational Resources"],
                bio: "Khalid Sheikh serves as Content Development Adviser at Cognia Education, bringing valuable experience as a high school teacher and content developer. His deep understanding of classroom dynamics and curriculum requirements ensures that all our professional development materials are practical, relevant, and immediately applicable. Khalid's expertise helps translate complex AI concepts into accessible, teacher-friendly content that resonates with educators at all levels."
              },
              {
                name: "Tanzeer Bhuiyan",
                role: "Education & Communication Adviser",
                qualifications: "Speech Specialist (trained under Vinh Giang), Education Specialist",
                experience: "Public figure and education specialist with expertise in communication",
                expertise: ["Public Speaking", "Communication Strategy", "Educational Leadership", "Professional Presentation", "Teacher Engagement"],
                bio: "Tanzeer Bhuiyan brings a unique combination of communication excellence and educational expertise to Cognia Education. As a public figure and speech specialist trained under the renowned Vinh Giang, Tanzeer ensures our professional development sessions are engaging, inspiring, and transformative. His advisory role focuses on enhancing the delivery and impact of our training programs, ensuring that teachers not only learn about AI but are genuinely excited to implement it in their classrooms."
              }
            ].map((member, index) => (
              <div 
                key={index}
                className="glass-card p-6 rounded-[32px] group cursor-pointer"
                style={{
                  ...glassStyles.glass,
                  minHeight: '200px'
                }}
              >
                <div className="text-white">
                    {/* Always visible: Name, Role, Qualifications */}
                    <h3 className="text-2xl font-bold mb-2">{member.name}</h3>
                    <p className="text-lg font-semibold text-white/95 mb-3">{member.role}</p>
                    
                    <div className="mb-4">
                      <h4 className="font-semibold mb-2 flex items-center">
                        <GraduationCap className="w-4 h-4 mr-2" />
                        Qualifications
                      </h4>
                      <p className="text-white/90 text-sm">{member.qualifications}</p>
                    </div>

                    {/* Always visible: Experience, Expertise, About */}
                    <div>
                      <div className="mb-4">
                        <h4 className="font-semibold mb-2 flex items-center">
                          <Briefcase className="w-4 h-4 mr-2" />
                          Experience
                        </h4>
                        <p className="text-white/90 text-sm">{member.experience}</p>
                      </div>

                      <div className="mb-4">
                        <h4 className="font-semibold mb-2 flex items-center">
                          <Star className="w-4 h-4 mr-2" />
                          Expertise
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {member.expertise.map((skill, skillIndex) => (
                            <span 
                              key={skillIndex}
                              className="px-3 py-1 rounded-full text-xs font-medium"
                              style={{
                                background: 'rgba(69, 123, 157, 0.3)',
                                border: '1px solid rgba(69, 123, 157, 0.5)'
                              }}
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-2 flex items-center">
                          <Users className="w-4 h-4 mr-2" />
                          About
                        </h4>
                        <p className="text-white/90 text-sm leading-relaxed">{member.bio}</p>
                      </div>
                    </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}

// Contact Page Component
function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    school: '',
    phone: '',
    message: '',
    preferredContact: 'email'
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    // Handle form submission
    console.log('Form submitted:', formData)
  }

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a365d] via-[#2a6496] to-[#457b9d] pt-24 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Moving Grid Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff_1px,transparent_1px),linear-gradient(to_bottom,#ffffff_1px,transparent_1px)] bg-[size:40px_40px] animate-[moveGrid_20s_linear_infinite]"></div>
        </div>
        
        {/* Floating Orbs */}
        <div className="absolute top-20 left-10 w-64 h-64 bg-cyan-400/20 rounded-full blur-3xl animate-[float_8s_ease-in-out_infinite]"></div>
        <div className="absolute bottom-20 right-10 w-80 h-80 bg-blue-400/20 rounded-full blur-3xl animate-[float_10s_ease-in-out_infinite_2s]"></div>
        <div className="absolute top-1/2 left-1/3 w-72 h-72 bg-purple-400/15 rounded-full blur-3xl animate-[float_12s_ease-in-out_infinite_4s]"></div>
      </div>
      <div className="container mx-auto px-4 py-16 relative z-10">
        <div 
          className="max-w-4xl mx-auto p-8 rounded-[32px] glass-hover transition-transform duration-300 hover:scale-105"
          style={glassStyles.glassCard}
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6 text-center animate-fadeInUp">
            Contact Us
          </h1>
          <p className="text-xl text-white/90 text-center mb-12 animate-slideInLeft" style={{animationDelay: '0.2s'}}>
            Ready to bring AI proficiency training to your school?
          </p>
          
          <div className="max-w-2xl mx-auto">
            {/* Contact Information */}
            <div className="animate-fadeInUp" style={{animationDelay: '0.3s'}}>
              <h2 className="text-2xl font-bold text-white mb-6">Get in Touch</h2>
              <div className="space-y-6">
                {/* Email Button */}
                <a 
                  href="mailto:admin@cogniaedu.com.au"
                  className="flex items-center justify-center gap-3 p-6 rounded-[32px] glass-hover transition-all duration-300 hover:scale-105"
                  style={{
                    ...glassStyles.glassCard,
                    background: 'rgba(230, 57, 70, 0.2)',
                    border: '2px solid rgba(230, 57, 70, 0.3)'
                  }}
                >
                  <Mail className="w-8 h-8 text-white" />
                  <div className="text-left">
                    <p className="text-white font-semibold text-lg">Email Us</p>
                    <p className="text-white/90">admin@cogniaedu.com.au</p>
                  </div>
                </a>
                
                {/* Phone Button */}
                <a 
                  href="tel:+61402130206"
                  className="flex items-center justify-center gap-3 p-6 rounded-[32px] glass-hover transition-all duration-300 hover:scale-105"
                  style={{
                    ...glassStyles.glassCard,
                    background: 'rgba(69, 123, 157, 0.2)',
                    border: '2px solid rgba(69, 123, 157, 0.3)'
                  }}
                >
                  <Phone className="w-8 h-8 text-white" />
                  <div className="text-left">
                    <p className="text-white font-semibold text-lg">Call Us</p>
                    <p className="text-white/90">+61 0402 130 206</p>
                  </div>
                </a>
                
                {/* Service Area */}
                <div 
                  className="p-6 rounded-[32px] transition-transform duration-300 hover:scale-105"
                  style={glassStyles.glassCard}
                >
                  <div className="flex items-center gap-3 text-white">
                    <MapPin className="w-6 h-6 text-cyan-300" />
                    <div>
                      <p className="font-semibold text-lg">Service Area</p>
                      <p className="text-white/90">Australia-wide in-person delivery</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Team Page Component
function TeamPage() {
  const [isVisible, setIsVisible] = useState(false)
  const navigate = useNavigate()

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const teamMembers = [
    {
      id: 1,
      name: "Alif Rahman",
      role: "Co-Founder & Lead Educator",
      qualifications: "Graduate Diploma in Teaching, B.Eng Mechatronic Engineering",
      experience: "Primary and secondary classroom teacher with AI integration experience",
      expertise: ["AI in Education", "Teacher Professional Development", "AI Integration Strategies", "Educational Technology"],
      bio: "Alif delivers AI professional development sessions for educators, combining classroom teaching experience with technical knowledge. He specializes in translating complex AI concepts into practical teaching strategies that align with AITSL standards and classroom realities.",
      placeholder: "alif-rahman-headshot"
    },
    {
      id: 2,
      name: "Mahi Taher",
      role: "Co-Founder & IT Specialist",
      qualifications: "B.Sc Physics, IT Specialist",
      experience: "IT systems specialist with focus on educational technology implementation",
      expertise: ["AI Tools Training", "Educational Technology", "Technical Support", "System Integration"],
      bio: "Mahi provides technical expertise for AI professional development programs, ensuring educators can confidently navigate and implement AI tools in their schools. He specializes in making AI technology accessible and practical for classroom use.",
      placeholder: "mahi-taher-headshot"
    },
    {
      id: 3,
      name: "Khalid Sheikh",
      role: "Content Development Adviser",
      qualifications: "B.Ed Secondary Education",
      experience: "High school teacher and PD content developer",
      expertise: ["AI Curriculum Integration", "Secondary Education", "PD Content Design", "Pedagogical Strategy"],
      bio: "Khalid develops professional development content that translates AI concepts into classroom-ready strategies. His teaching experience ensures PD materials address real classroom challenges and align with curriculum requirements.",
      placeholder: "khalid-sheikh-headshot"
    },
    {
      id: 4,
      name: "Tanzeer Bhuiyan",
      role: "Education & Communication Adviser",
      qualifications: "Speech Specialist, Education Specialist",
      experience: "Professional development facilitator and communication specialist",
      expertise: ["PD Facilitation", "Teacher Engagement", "Professional Presentation", "Workshop Delivery"],
      bio: "Tanzeer enhances the delivery and engagement of AI professional development sessions. His communication expertise ensures training sessions are clear, engaging, and inspire educators to confidently implement AI in their teaching practice.",
      placeholder: "tanzeer-bhuiyan-headshot"
    }
  ]

  return (
    <div className="min-h-screen pt-24" style={{
      background: 'linear-gradient(135deg, #1a365d 0%, #2a6496 50%, #457b9d 100%)'
    }}>
      {/* Hero Section */}
      <section className="py-20 relative">
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a365d]/50 to-[#2a6496]/50"></div>
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className={`max-w-4xl mx-auto ${isVisible ? 'animate-fadeInUp' : 'opacity-0'}`}>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-white hover:animate-pulse-slow">
              Meet Our Team
            </h1>
            <p className="text-xl md:text-2xl mb-8 opacity-90 text-white animate-slideInLeft" style={{animationDelay: '0.3s'}}>
              The passionate educators and AI specialists behind Cognia Education's innovative professional development programs
            </p>
          </div>
        </div>
      </section>

      {/* Team Members Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-7xl mx-auto">
            {teamMembers.map((member, index) => (
              <div 
                key={member.id}
                className={`glass-card p-8 rounded-[32px] animate-fadeInUp`}
                style={{
                  ...glassStyles.glass,
                  animationDelay: `${index * 0.2}s`
                }}
              >
                <div className="text-white">
                    <h3 className="text-2xl font-bold mb-2">{member.name}</h3>
                    <p className="text-lg font-semibold text-white/95 mb-3">{member.role}</p>
                    
                    <div className="mb-4">
                      <h4 className="font-semibold mb-2 flex items-center">
                        <GraduationCap className="w-4 h-4 mr-2" />
                        Qualifications
                      </h4>
                      <p className="text-white/90 text-sm">{member.qualifications}</p>
                    </div>

                    <div className="mb-4">
                      <h4 className="font-semibold mb-2 flex items-center">
                        <Briefcase className="w-4 h-4 mr-2" />
                        Experience
                      </h4>
                      <p className="text-white/90 text-sm">{member.experience}</p>
                    </div>

                    <div className="mb-4">
                      <h4 className="font-semibold mb-2 flex items-center">
                        <Star className="w-4 h-4 mr-2" />
                        Expertise
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {member.expertise.map((skill, skillIndex) => (
                          <span 
                            key={skillIndex}
                            className="px-3 py-1 rounded-full text-xs font-medium"
                            style={{
                              background: 'rgba(69, 123, 157, 0.3)',
                              border: '1px solid rgba(69, 123, 157, 0.5)'
                            }}
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2 flex items-center">
                        <Users className="w-4 h-4 mr-2" />
                        About
                      </h4>
                      <p className="text-white/90 text-sm leading-relaxed">{member.bio}</p>
                    </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Values Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 animate-fadeInUp">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Our Team Values
            </h2>
            <p className="text-xl text-white/90 max-w-3xl mx-auto">
              The principles that guide our approach to AI education and professional development
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            {[
              {
                icon: <Lightbulb className="w-8 h-8" />,
                title: "Innovation",
                description: "Staying at the forefront of AI education technology and methodologies"
              },
              {
                icon: <Heart className="w-8 h-8" />,
                title: "Empathy",
                description: "Understanding the challenges teachers face and providing supportive solutions"
              },
              {
                icon: <Target className="w-8 h-8" />,
                title: "Practicality",
                description: "Delivering immediately applicable skills and knowledge for real classrooms"
              },
              {
                icon: <Users className="w-8 h-8" />,
                title: "Community",
                description: "Building a network of AI-confident educators across Australia"
              }
            ].map((value, index) => (
              <div 
                key={index}
                className="text-center p-6 rounded-3xl glass-hover animate-scaleIn"
                style={{
                  ...glassStyles.glass,
                  animationDelay: `${index * 0.1}s`
                }}
              >
                <div className="text-white mb-4 flex justify-center">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{value.title}</h3>
                <p className="text-white/90 text-sm">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 animate-fadeInUp">
              Ready to Work with Our Team?
            </h2>
            <p className="text-xl mb-8 text-white/90 max-w-3xl mx-auto animate-slideInLeft" style={{animationDelay: '0.2s'}}>
              Let our experienced team of AI education specialists transform your school's approach to artificial intelligence.
            </p>
            <div className="flex flex-col md:flex-row justify-center items-center gap-6 stagger-animation">
              <button 
                onClick={() => navigate('/contact')}
                className="px-8 py-4 text-lg font-semibold text-white rounded-3xl glass-button-hover cursor-pointer"
                style={{
                  ...glassStyles.glassButton,
                  background: 'rgba(230, 57, 70, 0.8)'
                }}
              >
                <Mail className="w-5 h-5 mr-2 inline" />
                Book a Consultation
              </button>
              <div className="text-center">
                <p className="text-lg font-semibold text-white">admin@cogniaedu.com.au</p>
                <p className="text-white/80">Serving schools across Australia</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

// Main App Component with Router
function App() {
  return (
    <Router>
      <div className="min-h-screen">
        <Header />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/course" element={<CoursePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
      </div>
    </Router>
  )
}

export default App

